/*
 * UART.c
 *
 * Created: 18.09.2024 13:53:53
 * Author : admin
 */ 

#include <avr/io.h>
#include <stdlib.h>
#include <avr/interrupt.h>

#define F_CPU 16000000UL

#include "serial.h"

void herbert(uint8_t value) {
	serial_send_char(value);
}

int main(void)
{
	serial_init(herbert, BAUD9600);

	sei();
	 
    /* Replace with your application code */
    while (1) 
    {
    }
}

